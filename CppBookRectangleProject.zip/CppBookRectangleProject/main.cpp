#include <iostream>
#include <string>
using namespace std;

// Book structure
struct Book {
    string title;
    string author;
    float price;
};

// Rectangle class
class Rectangle {
private:
    float length;
    float breadth;

public:
    // Constructor
    Rectangle(float l, float b) {
        length = l;
        breadth = b;
    }

    // Method to calculate area
    float calculateArea() {
        return length * breadth;
    }
};

int main() {
    Book b;

    // Input book details
    cout << "Enter Book Title: ";
    getline(cin, b.title);
    cout << "Enter Book Author: ";
    getline(cin, b.author);
    cout << "Enter Book Price: ";
    cin >> b.price;

    // Display book details
    cout << "\nBook Details:\n";
    cout << "Title : " << b.title << endl;
    cout << "Author: " << b.author << endl;
    cout << "Price : " << b.price << endl;

    // Rectangle usage
    Rectangle rect(5.0, 3.5);
    cout << "\nRectangle Area: " << rect.calculateArea() << endl;

    return 0;
}
