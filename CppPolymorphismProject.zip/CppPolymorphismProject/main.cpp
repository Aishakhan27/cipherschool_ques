#include <iostream>
#include <cmath>
using namespace std;

// Abstract base class Shape
class Shape {
public:
    virtual float area() = 0; // Pure virtual function
    virtual ~Shape() {}       // Virtual destructor for base class
};

// Derived class Circle
class Circle : public Shape {
private:
    float radius;
public:
    Circle(float r) : radius(r) {}
    float area() override {
        return M_PI * radius * radius;
    }
    ~Circle() {
        cout << "Circle Destructor Called" << endl;
    }
};

// Derived class Square
class Square : public Shape {
private:
    float side;
public:
    Square(float s) : side(s) {}
    float area() override {
        return side * side;
    }
    ~Square() {
        cout << "Square Destructor Called" << endl;
    }
};

// Base class with virtual destructor
class Base {
public:
    virtual ~Base() {
        cout << "Base Destructor Called" << endl;
    }
};

// Derived class from Base
class Derived : public Base {
public:
    ~Derived() {
        cout << "Derived Destructor Called" << endl;
    }
};

int main() {
    // Polymorphism with abstract class
    Shape* shape1 = new Circle(5.0);
    Shape* shape2 = new Square(4.0);

    cout << "Area of Circle : " << shape1->area() << endl;
    cout << "Area of Square : " << shape2->area() << endl;

    delete shape1; // Should call Circle destructor
    delete shape2; // Should call Square destructor

    cout << "------------------------" << endl;

    // Demonstrating virtual destructor behavior
    Base* ptr = new Derived();
    delete ptr; // Should call Derived and Base destructors

    return 0;
}
