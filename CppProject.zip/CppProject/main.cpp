#include <iostream>
#include "Person.h"
using namespace std;

// Student class for demo
class Student {
private:
    int rollNumber;
    float marks;

public:
    void setRollNumber(int r) {
        rollNumber = r;
    }

    void setMarks(float m) {
        marks = m;
    }

    int getRollNumber() {
        return rollNumber;
    }

    float getMarks() {
        return marks;
    }
};

int main() {
    // Person class usage
    Person p("Aisha", 20);
    p.display();

    cout << "--------------------" << endl;

    // Student class usage
    Student s;
    s.setRollNumber(101);
    s.setMarks(92.5);

    cout << "Roll Number: " << s.getRollNumber() << endl;
    cout << "Marks      : " << s.getMarks() << endl;

    // ❌ Uncommenting below lines will cause errors
    // s.rollNumber = 999;
    // cout << s.marks;

    return 0;
}
